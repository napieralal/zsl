#include <iostream>
#include <cstdlib>


using namespace std;


int main(){
    int p,q,n,i=0,a,x=0,y=0,pole,suma;
    cin>>p; //
    cin>>q; //
    cin>>n; //liczba figur
    a=(q-p)/n;
    if(i<n)
    {
    x=((p+i*a)+(p+(i+1)*a))/2;
    y=(-1*x)*x+6*x-4;
    i++;
    pole=a*y;
    suma+=pole;
    }
    cout<<suma<<endl<<pole; //pole
    return 0;
}