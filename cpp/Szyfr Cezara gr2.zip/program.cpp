#include<iostream>
#include<cstdlib>
#include<cstring>
using namespace std;
int main()
{
    char abc[26]={ 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J','K', 'L', 'M', 'N', 'O', 'P','Q' ,'R', 'S', 'T', 'U','V', 'W', 'X', 'Y', 'Z'};
    string tekst="";
    string wynik="";
    int k=3,i,j;
    cin>>tekst;
    for(int i=0; i<tekst.length();i++){
        for(int j=0; j<26; j++) 
                if(tekst[i] == abc[j]) 
                {
                wynik[i]=abc[(j+k)%26];
                }
    cout<<wynik[i];
    }
    return 0;
}