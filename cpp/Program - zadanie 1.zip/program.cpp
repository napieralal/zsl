#include <iostream>
#include <cstdlib>
#include <ctime>
#include<fstream>
#include <string>
#include <limits.h>
#include <vector>

using namespace std;

struct Jacht{
    int pojemnosc;
    int paliwo;
    int dystans;
    std::vector<Jacht> v;
   Jacht(){ 
       pojemnosc = rand() % 500+100;
       paliwo = rand() % 200+50;
        dystans=(200*paliwo)/pojemnosc;
}
Jacht(int i,int j){
        pojemnosc=i;
        paliwo=j;
        dystans=200*paliwo/pojemnosc;
    }
     
     void nowa_wartosc(int j){
        paliwo+=j;
    }

    void wyswietl(){
        cout<<"Pojemnosc jachtu wynosi: "<<pojemnosc<<endl;
        cout<<"Ilość paliwa jachtu wynosi: "<<paliwo<<endl;
        cout<<"Dystans jaki może pokonać jacht wynosi: "<<dystans<<endl<<endl;
    }
    
    int zwroc_pojemnosc(){return pojemnosc;}
    int zwroc_paliwo(){return paliwo;}
    int zwroc_dystans(){return dystans;}
    
};

int main(){
    vector<Jacht> v;
    for(int i=0;i<20;i++){
        v.push_back(Jacht());
    }
    for(int i=0;i<v.size();i++){
        v[i].wyswietl();
    }
    Jacht maks=v[0];
    for(int i=0;i<v.size();i++){
       if(maks.zwroc_dystans)<v[i].zwroc_dystans() maks=v[i];
       maks.wyswietl();
    }
    return 0;
}