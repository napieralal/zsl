#include <iostream>
#include <cstdlib>
#include <cmath>

using namespace std;

int main(){
    float p,e,l,a,b,i=0;
    cin>>p;  //pierwiastek
    cin>>e;  //dokladnosc
    cin>>l;  //liczbapowtorzen
    a=p;
    b=p/a;
    while(abs(a-b)>=e||i<l)
    {
    a=(a+b)/2;
    b=p/a;
    i++;
    }
    cout<<a<<endl; //wynik pierwiastka
}