#include <iostream>
#include <cstdlib>
#include <stack>
#include <string>

using namespace std;

double ONP(string r){
        stack<double> stos;
        int size = r.length();
        double wa=0;
        double wb=0;
        double l=0;
    for(int i=0;i<size;i++){
    switch (r[i])
    {
        case '+':
        wa=stos.top();
        stos.pop();
        wb=stos.top();
        stos.pop();
        stos.push(wb+wa);
        break;
        case '-':
        wa=stos.top();
        stos.pop();
        wb=stos.top();
        stos.pop();
        stos.push(wb-wa);
        break;
        case '*':
        wa=stos.top();
        stos.pop();
        wb=stos.top();
        stos.pop();
        stos.push(wb*wa);         
        break;
        case '/':
        wa=stos.top();
        stos.pop();
        wb=stos.top();
        stos.pop();
        stos.push(wb/wa);
        break;
        case ' ':
        if(l!=0)stos.push(l);
        l=0;
        default:
        l=10*l+r[i]-'0';
        break;
    }
    }
    return stos.top();
}

int main(){
    string rownanie;
    cout<<"podaj rownanie: "<<endl;
    getline(cin,rownanie); 
    int size=rownanie.length();
    int val=0;
    for(int i=0;i<size;i++)
    {
        if(rownanie[i]!=' '){
        val=10*val+rownanie[i]-'0';}
        else{ 
        cout<<val<<endl;
        val=0;
        }
    } 
    cout<<ONP(rownanie);
    
    return 0;
}