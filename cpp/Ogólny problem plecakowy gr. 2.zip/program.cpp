#include <iostream>
#include <cstdlib>

using namespace std;

int main(){
    int n,Wp;
    cout<<"Podaj ilosc przedmiotow ";
    cin>>n;
    cout<<"Podaj wage plecaka ";
    cin>>Wp;
    int V[n];
    int W[n];
    int K[n];
    for(int i=0;i<n;i++)
    {
        cout<<"Podaj wartość"<<i+1<<"przedmiotu ";
        cin>>V[i];
        cout<<"Podaj wagę"<<i+1<<"przedmiotu ";
        cin>>W[i];
    }
    int i=1;
    int wynik=0;
    while(i<=n)
    {
        K[i]=Wp/W[i];
        Wp=Wp-(K[i]*W[i]);
        wynik=wynik+V[i]*K[i];
        i++;
    }
    cout<<"Wynik wynosi"<<wynik<<endl<<"Zawartość plecaka: ";
    for(int i=1;i<=n;i++)
    {
    cout<<K[i]<<endl;    
    }
    return 0;
}